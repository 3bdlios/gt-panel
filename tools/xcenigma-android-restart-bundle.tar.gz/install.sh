#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 ./reboot-android.py --check
stamp=$(date +%Y%m%d-%H%M%S)-$$
backup=/etc/xcenigma-android-backups/install-$stamp
mkdir -p "$backup"
plugin=usr/lib/enigma2/python/Plugins/SystemPlugins/XCAndroidRestart
helper=usr/lib/xcenigma/reboot-android.py
for file in "$plugin" "$helper" usr/lib/xcenigma/android-env-once.py; do
 if [ -e "/$file" ]; then
  mkdir -p "$backup/$(dirname "$file")"
  cp -a "/$file" "$backup/$file"
 fi
done
tar -xzf ./xcenigma-android-restart.tar.gz -C /
printf '%s\n' 'Installed. Restart the Enigma2 interface to show Restart to Android in the shutdown menu.' "Backup: $backup" 'No reboot or boot-screen changes performed.'
