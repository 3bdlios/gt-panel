#!/usr/bin/env python3
"""XCEnigma Android restart v1.1: verified environment one-shot, no boot UI changes."""
import argparse, importlib.util, os, subprocess, sys
from pathlib import Path
TOOL=Path('/usr/lib/xcenigma/android-env-once.py')
def module():
    local=Path(__file__).parent/'android-env-once.py'
    p=local if local.exists() else TOOL
    s=importlib.util.spec_from_file_location('android_env',str(p));m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    m.verify_host()
    return m

def cancel(m):
    raw=m.read_env()
    if m.parse(raw).get(b'bootfromnand')==b'0':print('NOT_ARMED');return
    for d in sorted(Path('/etc').glob('gtcombo-env-backup-*'),key=lambda d:d.stat().st_mtime,reverse=True):
        a,b=d/'env-armed.bin',d/'env-before.bin'
        if a.is_file() and b.is_file() and a.read_bytes()==raw:
            before=b.read_bytes()
            if m.plan(before)[0]!=raw:continue
            fd=os.open('/dev/env',os.O_RDWR|os.O_SYNC)
            try:
                if os.pread(fd,m.SIZE,0)!=raw:raise RuntimeError('Environment changed')
                m.write_exact(fd,before)
                if os.pread(fd,m.SIZE,0)!=before:raise RuntimeError('Cancel readback failed')
            finally:os.close(fd)
            print('REQUEST_CANCELLED');return
    raise RuntimeError('No matching verified backup; refusing environment write')
def main():
    p=argparse.ArgumentParser(description=__doc__);g=p.add_mutually_exclusive_group()
    for mode in ('check','arm','android','cancel'):g.add_argument('--'+mode,action='store_true')
    args=p.parse_args();m=module()
    if args.cancel:cancel(m);return
    raw=m.read_env();m.plan(raw)
    if not (args.arm or args.android):print('COMPATIBLE_VERIFIED_BOOT_PROFILE; CHECK_ONLY');return
    subprocess.run(['/usr/bin/python3',str(TOOL),'--arm','--expect-sha256',m.sha(raw)],check=True)
    if args.android:
        subprocess.run(['/etc/init.d/avahi-daemon','stop'],check=True)
        subprocess.run(['/sbin/reboot'],check=True)
if __name__=='__main__':
    try:main()
    except Exception as e:print('STOP:',e,file=sys.stderr);sys.exit(1)
