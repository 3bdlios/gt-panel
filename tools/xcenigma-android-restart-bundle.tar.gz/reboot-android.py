#!/usr/bin/env python3
"""One-shot Android request for the verified XCEnigma USB image. No env writes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

HASHES = {
    'cfgload': '2258b8e55e07a197f7e30e2e14a8b92cb49cdb6ef67b60cbd136829e94115925',
    'cfgload_env': '5e4538a443dc03e1c9ad36d78527ac32e3f77ca29ca8c8dbaa9be285b7205fed',
}
FLASH = Path('/flash')

def verify():
    if os.geteuid() != 0:
        raise RuntimeError('Run as root')
    mounts = [line.split() for line in Path('/proc/mounts').read_text().splitlines()]
    flash = next((m for m in mounts if m[1] == '/flash'), None)
    root = next((m for m in mounts if m[1] == '/'), None)
    if not flash or not root or flash[2] != 'vfat':
        raise RuntimeError('Expected USB /flash FAT mount')
    fdev, rdev = os.path.realpath(flash[0]), os.path.realpath(root[0])
    if not re.fullmatch(r'/dev/sd[a-z]+1', fdev) or rdev != fdev[:-1] + '2':
        raise RuntimeError('USB root and flash must be partitions 2 and 1 of the same disk')
    for name, digest in HASHES.items():
        p = FLASH / name
        if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest() != digest:
            raise RuntimeError('Unsupported boot script: ' + name)
    marker = FLASH / 'android.once'
    if marker.is_symlink() or (marker.exists() and not marker.is_file()):
        raise RuntimeError('Unexpected Android marker')
    if marker.exists() and marker.stat().st_size > 4096:
        raise RuntimeError('Unexpected Android marker size')
    return 'ro' in flash[3].split(',')

def request(cancel=False):
    readonly = verify()
    marker = FLASH / 'android.once'
    backup = Path('/etc/xcenigma-android-backups') / (time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex)
    backup.mkdir(parents=True, mode=0o700)
    existed = marker.exists()
    previous = marker.read_bytes() if existed else None
    if existed:
        (backup / 'android.once.before').write_bytes(previous)
    (backup / 'request.json').write_text(json.dumps({'previous_marker_existed': existed, 'action': 'cancel' if cancel else 'android', 'internal_environment_written': False}))
    changed = False
    try:
        if readonly:
            subprocess.run(['mount', '-o', 'remount,rw', '/flash'], check=True)
        # Verify again after remount, before writing the one-shot marker.
        verify()
        with marker.open('wb') as f:
            f.write(b'\0\0' if cancel else b'A')
            f.flush()
            os.fsync(f.fileno())
        changed = True
        os.sync()
        if marker.read_bytes() != (b'\0\0' if cancel else b'A'):
            raise RuntimeError('Marker verification failed')
    except Exception:
        # Disarm on failure; never restore an old armed marker automatically.
        if changed or marker.exists():
            try:
                with marker.open('wb') as f:
                    f.write(b'\0\0'); f.flush(); os.fsync(f.fileno())
                os.sync()
            except OSError:
                pass
        raise
    finally:
        if readonly:
            subprocess.run(['mount', '-o', 'remount,ro', '/flash'], check=True)
    print('ANDROID_REQUEST_CANCELLED' if cancel else 'ANDROID_ONCE_ARMED', flush=True)
    print('Backup: ' + str(backup), flush=True)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    modes = p.add_mutually_exclusive_group()
    modes.add_argument('--check', action='store_true', help='Read-only compatibility check (default)')
    modes.add_argument('--android', action='store_true', help='Arm one-shot Android and reboot')
    modes.add_argument('--cancel', action='store_true', help='Disarm the USB request, without reboot')
    args = p.parse_args()
    if args.android or args.cancel:
        request(cancel=args.cancel)
        if args.android:
            subprocess.run(['/sbin/reboot'], check=True)
    else:
        verify()
        print('COMPATIBLE_USB_BOOT_FILES; Android boot outcome still requires a device test')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print('STOP: ' + str(exc), file=sys.stderr)
        sys.exit(1)
