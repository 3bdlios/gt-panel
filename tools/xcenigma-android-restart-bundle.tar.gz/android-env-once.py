#!/usr/bin/env python3
"""Verified one-shot boot flag. Default --check is read-only. Never reboots."""
import argparse, hashlib, json, os, re, stat, struct, tempfile, zlib
from pathlib import Path
SIZE=65536
BOOT_SHA='b6f01df81e74a83a52179b7cfdbaf5466833dae47c5b9a8202d9d66861ead36c'
BOOTCMD=b'if test ${bootfromnand} = 1; then setenv bootfromnand 0; saveenv; else run bootfromsd; run bootfromusb; run bootfromemmc; fi; run storeboot'

PROFILE_COMMANDS={b'storeboot': 'cd7998f3d24bf739916bf51a6598458c54cffb8ab3162063f2dbcf10d121b2a6', b'storeargs': '771a246cf40ed563a0d86600da381435a919bbe131cabb93617ff01cd8041b26', b'bootfromsd': 'bd0026c3dec0c8c346c1b6c6e05d2f5c82fcdfcbd85adab09e3607dbf335b127', b'bootfromusb': 'f6794667642283bdb9184ca72d71e00bbc8f5cfbc6ac680164ac3b2427affc0d', b'bootfromemmc': '076357eb4c5e0c13a14447032cfee704f1208899371acdd10181194f73edb146'}

def sha(b): return hashlib.sha256(b).hexdigest()

def parse(raw):
    if len(raw)!=SIZE or struct.unpack('<I',raw[:4])[0] != zlib.crc32(raw[4:])&0xffffffff:
        raise RuntimeError('Invalid 64KiB environment CRC')
    end=raw.find(b'\0\0',4)
    if end<0: raise RuntimeError('No environment terminator')
    result={}
    for entry in raw[4:end].split(b'\0'):
        if b'=' not in entry: raise RuntimeError('Invalid environment record')
        key,value=entry.split(b'=',1)
        if key in result: raise RuntimeError('Duplicate environment key')
        result[key]=value
    return result

def plan(raw):
    env=parse(raw)
    if env.get(b'bootcmd')!=BOOTCMD: raise RuntimeError('Boot command changed; stop for review')
    if env.get(b'bootfromnand')!=b'0': raise RuntimeError('One-shot flag is already set or unknown')
    needle=b'\0bootfromnand=0\0'
    if raw.count(needle)!=1: raise RuntimeError('Ambiguous flag location')
    patched=bytearray(raw)
    offset=raw.index(needle)+len(b'\0bootfromnand=')
    patched[offset]=ord('1')
    patched[:4]=struct.pack('<I',zlib.crc32(patched[4:])&0xffffffff)
    after=bytes(patched); expected=dict(env); expected[b'bootfromnand']=b'1'
    if parse(after)!=expected: raise RuntimeError('Unexpected variable change')
    if any(raw[i]!=after[i] for i in range(4,SIZE) if i!=offset): raise RuntimeError('Unexpected byte change')
    return after,offset

def verify_host():
    model=Path('/proc/device-tree/model').read_bytes().rstrip(b'\0\r\n ')
    expected_boot_sha={b'GTMedia GT Combo':BOOT_SHA,b'XCONN':'9788581f8fba433a68daf425db45f887b9c88f3190aa585f0ad1acbbb84a7e3d'}.get(model)
    if expected_boot_sha is None: raise RuntimeError('Unexpected hardware')
    if model==b'XCONN':
        if Path('/proc/device-tree/coreelec-dt-id').read_bytes().rstrip(b'\0\r\n ')!=b'sm1_s905x3_gtcombo': raise RuntimeError('Unexpected XCONN DT identity')
        if parse(read_env()).get(b'aml_dt')!=b'sm1_ac213_4g': raise RuntimeError('Unexpected XCONN Android identity')
    for name,minor in (('/dev/bootloader',1),('/dev/env',4)):
        s=os.stat(name)
        if not stat.S_ISBLK(s.st_mode) or os.major(s.st_rdev)!=179 or os.minor(s.st_rdev)!=minor:
            raise RuntimeError('Unexpected block device mapping: '+name)
    with open('/dev/bootloader','rb',buffering=0) as f:
        observed_boot_sha=sha(f.read(4194304))
        allowed={expected_boot_sha}
        if model==b'GTMedia GT Combo':allowed.add('c20d2a095ec2a4c2b11cc59825849835b81788ceb50012145258b48cf070ed41')
        if observed_boot_sha not in allowed:raise RuntimeError('Unsupported bootloader; no changes')
    if observed_boot_sha=='c20d2a095ec2a4c2b11cc59825849835b81788ceb50012145258b48cf070ed41':
        env=parse(read_env())
        if env.get(b'aml_dt')!=b'sm1_ac213_2g':raise RuntimeError('Unexpected Android DT identity')
        for key,expected in PROFILE_COMMANDS.items():
            if sha(env.get(key,b''))!=expected:raise RuntimeError('Unexpected boot command: '+key.decode())
    mounts=[l.split() for l in Path('/proc/mounts').read_text().splitlines()]
    root=next(m for m in mounts if m[1]=='/'); flash=next(m for m in mounts if m[1]=='/flash')
    rdev=os.path.realpath(root[0]); fdev=os.path.realpath(flash[0])
    if not re.fullmatch(r'/dev/sd[a-z]+2',rdev) or re.sub(r'\d+$','',rdev)!=re.sub(r'\d+$','',fdev):
        raise RuntimeError('Backup directory must be on verified USB root')
    return rdev

def read_env():
    with open('/dev/env','rb',buffering=0) as f: return f.read(SIZE)

def write_exact(fd,data):
    off=0
    while off<len(data):
        n=os.pwrite(fd,data[off:],off)
        if n<=0: raise RuntimeError('Short device write')
        off+=n
    os.fsync(fd)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--arm',action='store_true',help='Writes internal environment after verified backup')
    ap.add_argument('--expect-sha256',help='Exact original environment hash from the read-only check')
    ap.add_argument('--check',action='store_true')
    args=ap.parse_args()
    if args.arm and args.check: raise RuntimeError('Select check or arm')
    root=verify_host(); before=read_env(); after,offset=plan(before)
    print('BOOTLOADER MATCH; ENV CRC VALID; USB ROOT:',root)
    print('ENV_SHA256:',sha(before))
    print('NEW_ENV_SHA256:',sha(after))
    print('PLAN: bootfromnand 0 -> 1 at data byte',offset,'plus four CRC bytes; no other variables changed.')
    print('Existing bootcmd resets the flag to 0 before attempting internal Android.')
    if not args.arm:
        print('CHECK ONLY: nothing written.'); return
    if os.geteuid()!=0 or args.expect_sha256!=sha(before):
        raise RuntimeError('Root and matching --expect-sha256 required before writing')
    backup=Path(tempfile.mkdtemp(prefix='gtcombo-env-backup-',dir='/etc'))
    os.chmod(backup,0o700)
    for name,data in (('env-before.bin',before),('env-armed.bin',after)):
        with (backup/name).open('xb') as f: f.write(data); f.flush(); os.fsync(f.fileno())
        if (backup/name).read_bytes()!=data: raise RuntimeError('Backup verification failed')
    meta={'device':'/dev/env','offset':0,'length':SIZE,'original_sha256':sha(before),'armed_sha256':sha(after),'bootloader_sha256':hashlib.sha256(Path('/dev/bootloader').open('rb').read(4194304)).hexdigest()}
    with (backup/'metadata.json').open('x') as f:
        json.dump(meta,f,indent=2); f.flush(); os.fsync(f.fileno())
    os.sync(); print('VERIFIED BACKUP:',backup,flush=True)
    fd=os.open('/dev/env',os.O_RDWR|os.O_SYNC)
    try:
        if os.pread(fd,SIZE,0)!=before: raise RuntimeError('Environment changed after review; refusing write')
        try:
            write_exact(fd,after)
            if os.pread(fd,SIZE,0)!=after: raise RuntimeError('Armed environment readback mismatch')
        except Exception:
            print('Write failed; attempting to restore verified original.',flush=True)
            write_exact(fd,before)
            if os.pread(fd,SIZE,0)!=before: raise RuntimeError('CRITICAL: restore readback failed; do not reboot')
            raise
    finally: os.close(fd)
    print('ARMED AND READBACK VERIFIED. No reboot performed.')
    print('Keep this backup; do not arm again. Next normal reboot should bypass USB once.')

if __name__=='__main__':
    try: main()
    except Exception as e: print('STOP:',e); raise SystemExit(1)
