#!/usr/bin/env python3
"""Shared one-shot Android helper; callers must obtain an explicit Android choice."""
import importlib.util, os, subprocess, sys
from pathlib import Path
TOOL=Path('/usr/lib/gtcombo/android-once.py')
def main():
    if len(sys.argv)!=2 or sys.argv[1] not in ('--arm','--check'):
        raise RuntimeError('Use --arm or --check; no automatic cancel/environment write')
    spec=importlib.util.spec_from_file_location('gt_android_once',str(TOOL))
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    m.verify_host(); raw=m.read_env(); m.plan(raw)
    if sys.argv[1]=='--check':
        print('ANDROID_HELPER_CHECK_OK: no changes'); return
    log=Path('/etc/gtcombo-android-last-request.log')
    if log.is_symlink():raise RuntimeError('Unexpected log symlink')
    with log.open('a') as f:
        f.write('ANDROID_REQUEST_SELECTED\n'); f.flush(); os.fsync(f.fileno())
        result=subprocess.run(['/usr/bin/python3',str(TOOL),'--arm','--expect-sha256',m.sha(raw)],stdout=f,stderr=subprocess.STDOUT)
        f.write('RESULT=%d\n'%result.returncode); f.flush(); os.fsync(f.fileno())
    if result.returncode:raise RuntimeError('Could not prepare Android. Log: '+str(log))
    print('ANDROID_ONCE_ARMED',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:print('ANDROID_BOOT_ERROR:',e,file=sys.stderr);sys.exit(1)
