GT Panel Skins example. This is a harmless text file, not a device repair.
