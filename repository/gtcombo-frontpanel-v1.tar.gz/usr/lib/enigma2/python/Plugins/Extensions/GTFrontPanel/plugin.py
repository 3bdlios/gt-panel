"""GT Combo permanent local clock. No GPIO work in Enigma2."""
import os
import subprocess
import time
from enigma import eTimer
from Plugins.Plugin import PluginDescriptor

_controller = None

class Controller:
    def __init__(self, session):
        self.session = session
        self.child = None
        self.log = None
        self.last = None
        self.timer = eTimer()
        self.timer.callback.append(self.tick)
        try:
            self.log = open('/tmp/gt-frontpanel.log', 'ab', buffering=0)
            self.child = subprocess.Popen(['/usr/bin/python3', '-u', '/usr/lib/gtcombo/frontpanel/worker.py'], stdin=subprocess.PIPE, stdout=self.log, stderr=self.log, close_fds=True)
            os.set_blocking(self.child.stdin.fileno(), False)
            self.timer.start(2000, False)
            self.tick()
        except Exception as error:
            print('[GTFrontPanel]', error)
            self.close()

    def tick(self):
        try:
            if self.child is None or self.child.poll() is not None:
                self.close()
                return
            text = time.strftime('%H%M')
            if text != self.last:
                os.write(self.child.stdin.fileno(), (text + '\n').encode('ascii'))
                self.last = text
        except BlockingIOError:
            pass
        except Exception as error:
            print('[GTFrontPanel]', error)
            self.close()

    def close(self):
        self.timer.stop()
        if self.child is not None:
            try:
                self.child.stdin.close()
            except Exception:
                pass
            self.child = None
        if self.log is not None:
            self.log.close()
            self.log = None

def sessionstart(reason, session=None, **kwargs):
    global _controller
    if reason == 0 and session is not None and _controller is None:
        _controller = Controller(session)
    elif reason != 0 and _controller is not None:
        _controller.close()
        _controller = None

def Plugins(**kwargs):
    return [PluginDescriptor(name='GT Front Panel', description='Permanent local 24-hour clock', where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart)]
