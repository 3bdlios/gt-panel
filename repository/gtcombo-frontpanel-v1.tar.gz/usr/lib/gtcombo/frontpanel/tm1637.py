#!/usr/bin/env python3
"""GT Combo TM1637: GPIOAO_2 clock, GPIOAO_3 open-drain data.
Default --check reads chip/line information without requesting output lines.
--show 1234 makes a temporary display write; no boot/service configuration.
"""
from pathlib import Path
import argparse,fcntl,os,re,struct,time,zlib
DIGITS=(0x9f,0x82,0xad,0xa7,0xb2,0x37,0x3f,0x83,0xbf,0xb7)

def ioctl_num(n,size,direction=3):return (direction<<30)|(size<<16)|(0xb4<<8)|n

def verify_board():
    if Path('/proc/device-tree/model').read_bytes().rstrip(b'\0\n ')!=b'GTMedia GT Combo':raise RuntimeError('Unexpected board')
    if os.uname().release!='5.15.196':raise RuntimeError('Unreviewed kernel')
    with open('/dev/env','rb',buffering=0) as f:data=f.read(65536)
    if len(data)!=65536 or struct.unpack('<I',data[:4])[0] != zlib.crc32(data[4:])&0xffffffff:raise RuntimeError('Invalid environment identity checksum')
    if b'\0aml_dt=sm1_ac213_2g\0' not in data:raise RuntimeError('Unexpected original Android board identity')

def chip_info(fd):
    info=bytearray(68);fcntl.ioctl(fd,ioctl_num(1,68,2),info,True)
    name,label,lines=struct.unpack('32s32sI',info)
    return name.rstrip(b'\0'),label.rstrip(b'\0'),lines

def line_info(fd,offset):
    info=bytearray(256);struct.pack_into('I',info,64,offset);fcntl.ioctl(fd,ioctl_num(5,256),info,True)
    name=bytes(info[:32]).rstrip(b'\0');consumer=bytes(info[32:64]).rstrip(b'\0')
    flags=struct.unpack_from('Q',info,72)[0]
    return name,consumer,flags

def find_chip():
    for path in sorted(Path('/dev').glob('gpiochip*')):
        fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC)
        try:
            name,label,lines=chip_info(fd)
            if label!=b'aobus-banks':continue
            if lines!=16:raise RuntimeError('Unexpected AO GPIO count')
            for offset,expected in ((2,b'GPIOAO_2'),(3,b'GPIOAO_3')):
                actual,consumer,flags=line_info(fd,offset)
                if actual!=expected:
                    if actual: raise RuntimeError('GPIO name mismatch')
                    pins=Path('/sys/kernel/debug/pinctrl/pinctrl@ff800014-pinctrl-meson/pinmux-pins').read_text()
                    match=r'^pin %d \(%s\): UNCLAIMED$'%(offset,expected.decode())
                    if not re.search(match,pins,re.MULTILINE): raise RuntimeError('GPIO pinmux identity/ownership mismatch')
                if flags&1 or consumer:raise RuntimeError('Display pin is already owned: '+str(offset))
            return str(path)
        finally:os.close(fd)
    raise RuntimeError('AO GPIO chip missing')

def encode(text):
    if len(text)!=4 or any(c not in '0123456789 ' for c in text):raise ValueError('Use four digits or spaces')
    return [0]+[DIGITS[int(c)] if c!=' ' else 0 for c in reversed(text)]+[0]

class Display:
    def __init__(self,delay=0.00008):
        self.fd=None;self.delay=delay;self.values=bytearray(64);self.values[0]=self.values[1]=1
        verify_board();path=find_chip();chip=os.open(path,os.O_RDONLY|os.O_CLOEXEC)
        try:
            req=bytearray(592);struct.pack_into('II',req,0,2,3)
            label=b'gtcombo-tm1637';req[256:256+len(label)]=label
            struct.pack_into('Q',req,288,(1<<3)|(1<<6)) # output + open-drain
            struct.pack_into('I',req,296,1) # initial released output values
            struct.pack_into('IIQQ',req,320,2,0,3,3)
            struct.pack_into('I',req,560,2)
            fcntl.ioctl(chip,ioctl_num(7,592),req,True)
            self.fd=struct.unpack_from('i',req,588)[0]
            if self.fd<0:raise RuntimeError('Invalid GPIO handle')
        finally:os.close(chip)
    def set(self,clk=None,data=None):
        if clk is not None:self.values[0]=int(bool(clk))
        if data is not None:self.values[1]=int(bool(data))
        fcntl.ioctl(self.fd,ioctl_num(15,16),struct.pack('QQ',self.values[0]|(self.values[1]<<1),3))
        time.sleep(self.delay)
    def start(self):self.set(clk=1,data=1);self.set(data=0)
    def stop(self):self.set(clk=0,data=0);self.set(clk=1);self.set(data=1)
    def byte(self,value):
        for n in range(8):
            self.set(clk=0);self.set(data=(value>>n)&1);self.set(clk=1)
        self.set(clk=0,data=1);self.set(clk=1)
        result=bytearray(struct.pack('QQ',0,2));fcntl.ioctl(self.fd,ioctl_num(14,16),result,True)
        ack=(struct.unpack_from('Q',result)[0]&2)==0;self.set(clk=0)
        if not ack:raise RuntimeError('TM1637 did not acknowledge byte 0x%02x; stopped'%value)
    def transaction(self,values):
        self.start()
        try:
            for value in values:self.byte(value)
        finally:self.stop()
    def show(self,text,brightness=2):
        data=encode(text)
        self.transaction([0x40]);self.transaction([0xc0]+data);self.transaction([0x88|(brightness&7)])
    def close(self):
        if self.fd is not None:
            try:self.set(clk=1,data=1)
            finally:os.close(self.fd);self.fd=None

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true');parser.add_argument('--show')
    args=parser.parse_args();verify_board();chip=find_chip();print('BOARD AND FREE GPIO LINES VERIFIED:',chip,'CLK=GPIOAO_2 DATA=GPIOAO_3')
    if args.show is None:print('READ-ONLY CHECK; no lines requested or display changed');return
    encode(args.show)
    display=Display()
    try:display.show(args.show);print('TM1637_ACK_OK; DISPLAY_REQUEST:',args.show)
    finally:display.close()
    print('GPIO handles released; no service installed or boot files changed')
if __name__=='__main__':
    try:main()
    except Exception as e:print('STOP:',e);raise SystemExit(1)
