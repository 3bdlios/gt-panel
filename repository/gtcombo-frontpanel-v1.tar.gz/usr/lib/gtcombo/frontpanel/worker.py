#!/usr/bin/python3
"""Separate process: GPIO errors cannot unwind the Enigma2 main loop."""
import sys
from tm1637 import Display

def main():
    display = Display()
    last = None
    try:
        for line in sys.stdin:
            text = line.rstrip('\n')
            if len(text) != 4 or any(c not in '0123456789 ' for c in text):
                continue
            if text != last:
                display.show(text)
                last = text
    finally:
        display.close()

if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print('GTFrontPanel stopped:', error, file=sys.stderr)
        sys.exit(1)
